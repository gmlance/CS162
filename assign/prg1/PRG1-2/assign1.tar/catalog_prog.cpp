/*
Grant Lance
933246876
CS 162 - Program 1 - Wizard Program
A program for reading and displaying text files
*/

#include <catalog.hpp>

using namespace std;

spellbook * create_spellbooks(int) {
    
}